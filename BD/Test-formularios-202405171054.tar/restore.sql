--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.2
-- Dumped by pg_dump version 15.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE formularios;
--
-- Name: formularios; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE formularios WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Latin America.1252';


ALTER DATABASE formularios OWNER TO postgres;

\connect formularios

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: acc_formulario_grupos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_formulario_grupos (
    id integer NOT NULL,
    formulario_id integer NOT NULL,
    grupo_id integer NOT NULL,
    privilegio5 boolean DEFAULT false NOT NULL,
    privilegio6 boolean DEFAULT false NOT NULL,
    privilegio7 boolean DEFAULT false NOT NULL,
    privilegio8 boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.acc_formulario_grupos OWNER TO postgres;

--
-- Name: acc_formulario_grupo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.acc_formulario_grupo_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.acc_formulario_grupo_id_seq OWNER TO postgres;

--
-- Name: acc_formulario_grupo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.acc_formulario_grupo_id_seq OWNED BY public.acc_formulario_grupos.id;


--
-- Name: acc_grupo_privilegios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_grupo_privilegios (
    id integer NOT NULL,
    grupo_id integer NOT NULL,
    privilegio_id integer NOT NULL,
    privilegio1 boolean DEFAULT false NOT NULL,
    privilegio2 boolean DEFAULT false NOT NULL,
    privilegio3 boolean DEFAULT false NOT NULL,
    privilegio4 boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.acc_grupo_privilegios OWNER TO postgres;

--
-- Name: acc_usuario_grupos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.acc_usuario_grupos (
    id integer NOT NULL,
    usuario_id integer NOT NULL,
    grupo_id integer NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.acc_usuario_grupos OWNER TO postgres;

--
-- Name: acc_usuario_grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.acc_usuario_grupos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.acc_usuario_grupos_id_seq OWNER TO postgres;

--
-- Name: acc_usuario_grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.acc_usuario_grupos_id_seq OWNED BY public.acc_usuario_grupos.id;


--
-- Name: clasificaciones; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.clasificaciones (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.clasificaciones OWNER TO postgres;

--
-- Name: clasificaciones_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.clasificaciones_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.clasificaciones_id_seq OWNER TO postgres;

--
-- Name: clasificaciones_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.clasificaciones_id_seq OWNED BY public.clasificaciones.id;


--
-- Name: departamentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.departamentos (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.departamentos OWNER TO postgres;

--
-- Name: departamentos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.departamentos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.departamentos_id_seq OWNER TO postgres;

--
-- Name: departamentos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.departamentos_id_seq OWNED BY public.departamentos.id;


--
-- Name: formularios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.formularios (
    id integer NOT NULL,
    titulo character varying(255) NOT NULL,
    descripcion text,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.formularios OWNER TO postgres;

--
-- Name: encuestas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.encuestas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.encuestas_id_seq OWNER TO postgres;

--
-- Name: encuestas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.encuestas_id_seq OWNED BY public.formularios.id;


--
-- Name: especies; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.especies (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL,
    talla_min integer DEFAULT 1 NOT NULL,
    talla_max integer DEFAULT 2 NOT NULL,
    peso_min integer DEFAULT 1 NOT NULL,
    peso_max integer DEFAULT 2 NOT NULL,
    talla_menor_a numeric DEFAULT 1 NOT NULL,
    tipo1 integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.especies OWNER TO postgres;

--
-- Name: especies_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.especies_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.especies_id_seq OWNER TO postgres;

--
-- Name: especies_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.especies_id_seq OWNED BY public.especies.id;


--
-- Name: failed_jobs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.failed_jobs (
    id bigint NOT NULL,
    uuid character varying(255) NOT NULL,
    connection text NOT NULL,
    queue text NOT NULL,
    payload text NOT NULL,
    exception text NOT NULL,
    failed_at timestamp(0) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public.failed_jobs OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.failed_jobs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.failed_jobs_id_seq OWNER TO postgres;

--
-- Name: failed_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.failed_jobs_id_seq OWNED BY public.failed_jobs.id;


--
-- Name: flotas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.flotas (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.flotas OWNER TO postgres;

--
-- Name: flotas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.flotas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.flotas_id_seq OWNER TO postgres;

--
-- Name: flotas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.flotas_id_seq OWNED BY public.flotas.id;


--
-- Name: grupo_privilegio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grupo_privilegio_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grupo_privilegio_id_seq OWNER TO postgres;

--
-- Name: grupo_privilegio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grupo_privilegio_id_seq OWNED BY public.acc_grupo_privilegios.id;


--
-- Name: grupos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.grupos (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.grupos OWNER TO postgres;

--
-- Name: grupos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.grupos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.grupos_id_seq OWNER TO postgres;

--
-- Name: grupos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.grupos_id_seq OWNED BY public.grupos.id;


--
-- Name: lugar_m; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.lugar_m (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.lugar_m OWNER TO postgres;

--
-- Name: lugar_m_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.lugar_m_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.lugar_m_id_seq OWNER TO postgres;

--
-- Name: lugar_m_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.lugar_m_id_seq OWNED BY public.lugar_m.id;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: naves; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.naves (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL,
    flota_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.naves OWNER TO postgres;

--
-- Name: naves_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.naves_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.naves_id_seq OWNER TO postgres;

--
-- Name: naves_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.naves_id_seq OWNED BY public.naves.id;


--
-- Name: password_reset_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.password_reset_tokens (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE public.password_reset_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personal_access_tokens (
    id bigint NOT NULL,
    tokenable_type character varying(255) NOT NULL,
    tokenable_id bigint NOT NULL,
    name character varying(255) NOT NULL,
    token character varying(64) NOT NULL,
    abilities text,
    last_used_at timestamp(0) without time zone,
    expires_at timestamp(0) without time zone,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.personal_access_tokens OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personal_access_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personal_access_tokens_id_seq OWNER TO postgres;

--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personal_access_tokens_id_seq OWNED BY public.personal_access_tokens.id;


--
-- Name: personas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.personas (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL,
    apellido character varying(255) NOT NULL,
    rut character varying(13) NOT NULL
);


ALTER TABLE public.personas OWNER TO postgres;

--
-- Name: personas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.personas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.personas_id_seq OWNER TO postgres;

--
-- Name: personas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.personas_id_seq OWNED BY public.personas.id;


--
-- Name: plantas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.plantas (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.plantas OWNER TO postgres;

--
-- Name: plantas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.plantas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.plantas_id_seq OWNER TO postgres;

--
-- Name: plantas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.plantas_id_seq OWNED BY public.plantas.id;


--
-- Name: privilegio_maestros; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.privilegio_maestros (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    descripcion character varying(255) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.privilegio_maestros OWNER TO postgres;

--
-- Name: privilegio_maestro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.privilegio_maestro_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.privilegio_maestro_id_seq OWNER TO postgres;

--
-- Name: privilegio_maestro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.privilegio_maestro_id_seq OWNED BY public.privilegio_maestros.id;


--
-- Name: puertos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.puertos (
    id integer NOT NULL,
    nombre character varying(255) NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    enabled boolean DEFAULT true NOT NULL
);


ALTER TABLE public.puertos OWNER TO postgres;

--
-- Name: puertos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.puertos_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.puertos_id_seq OWNER TO postgres;

--
-- Name: puertos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.puertos_id_seq OWNED BY public.puertos.id;


--
-- Name: resp_formularios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resp_formularios (
    id integer NOT NULL,
    formulario_id integer NOT NULL,
    json jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone,
    enabled boolean DEFAULT true NOT NULL,
    usuario_id integer DEFAULT 1 NOT NULL
);


ALTER TABLE public.resp_formularios OWNER TO postgres;

--
-- Name: resp_storage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.resp_storage (
    id integer NOT NULL,
    nombre character varying NOT NULL,
    url character varying NOT NULL,
    respuesta_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at timestamp without time zone
);


ALTER TABLE public.resp_storage OWNER TO postgres;

--
-- Name: resp_storage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.resp_storage_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.resp_storage_id_seq OWNER TO postgres;

--
-- Name: resp_storage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.resp_storage_id_seq OWNED BY public.resp_storage.id;


--
-- Name: respuestas_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.respuestas_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.respuestas_id_seq OWNER TO postgres;

--
-- Name: respuestas_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.respuestas_id_seq OWNED BY public.resp_formularios.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    email_verified_at timestamp(0) without time zone,
    password character varying(255) NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: usuarios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuarios (
    id integer NOT NULL,
    username character varying(255) NOT NULL,
    password character varying(255) NOT NULL,
    google_id integer,
    email character varying(50) NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    persona_id integer NOT NULL
);


ALTER TABLE public.usuarios OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuarios_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.usuarios_id_seq OWNER TO postgres;

--
-- Name: usuarios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuarios_id_seq OWNED BY public.usuarios.id;


--
-- Name: acc_formulario_grupos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_formulario_grupos ALTER COLUMN id SET DEFAULT nextval('public.acc_formulario_grupo_id_seq'::regclass);


--
-- Name: acc_grupo_privilegios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_grupo_privilegios ALTER COLUMN id SET DEFAULT nextval('public.grupo_privilegio_id_seq'::regclass);


--
-- Name: acc_usuario_grupos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_usuario_grupos ALTER COLUMN id SET DEFAULT nextval('public.acc_usuario_grupos_id_seq'::regclass);


--
-- Name: clasificaciones id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clasificaciones ALTER COLUMN id SET DEFAULT nextval('public.clasificaciones_id_seq'::regclass);


--
-- Name: departamentos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamentos ALTER COLUMN id SET DEFAULT nextval('public.departamentos_id_seq'::regclass);


--
-- Name: especies id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.especies ALTER COLUMN id SET DEFAULT nextval('public.especies_id_seq'::regclass);


--
-- Name: failed_jobs id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs ALTER COLUMN id SET DEFAULT nextval('public.failed_jobs_id_seq'::regclass);


--
-- Name: flotas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flotas ALTER COLUMN id SET DEFAULT nextval('public.flotas_id_seq'::regclass);


--
-- Name: formularios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formularios ALTER COLUMN id SET DEFAULT nextval('public.encuestas_id_seq'::regclass);


--
-- Name: grupos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupos ALTER COLUMN id SET DEFAULT nextval('public.grupos_id_seq'::regclass);


--
-- Name: lugar_m id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lugar_m ALTER COLUMN id SET DEFAULT nextval('public.lugar_m_id_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: naves id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.naves ALTER COLUMN id SET DEFAULT nextval('public.naves_id_seq'::regclass);


--
-- Name: personal_access_tokens id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens ALTER COLUMN id SET DEFAULT nextval('public.personal_access_tokens_id_seq'::regclass);


--
-- Name: personas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personas ALTER COLUMN id SET DEFAULT nextval('public.personas_id_seq'::regclass);


--
-- Name: plantas id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantas ALTER COLUMN id SET DEFAULT nextval('public.plantas_id_seq'::regclass);


--
-- Name: privilegio_maestros id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilegio_maestros ALTER COLUMN id SET DEFAULT nextval('public.privilegio_maestro_id_seq'::regclass);


--
-- Name: puertos id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.puertos ALTER COLUMN id SET DEFAULT nextval('public.puertos_id_seq'::regclass);


--
-- Name: resp_formularios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resp_formularios ALTER COLUMN id SET DEFAULT nextval('public.respuestas_id_seq'::regclass);


--
-- Name: resp_storage id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resp_storage ALTER COLUMN id SET DEFAULT nextval('public.resp_storage_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: usuarios id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios ALTER COLUMN id SET DEFAULT nextval('public.usuarios_id_seq'::regclass);


--
-- Data for Name: acc_formulario_grupos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_formulario_grupos (id, formulario_id, grupo_id, privilegio5, privilegio6, privilegio7, privilegio8, created_at, updated_at) FROM stdin;
\.
COPY public.acc_formulario_grupos (id, formulario_id, grupo_id, privilegio5, privilegio6, privilegio7, privilegio8, created_at, updated_at) FROM '$$PATH$$/3586.dat';

--
-- Data for Name: acc_grupo_privilegios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_grupo_privilegios (id, grupo_id, privilegio_id, privilegio1, privilegio2, privilegio3, privilegio4, created_at, updated_at) FROM stdin;
\.
COPY public.acc_grupo_privilegios (id, grupo_id, privilegio_id, privilegio1, privilegio2, privilegio3, privilegio4, created_at, updated_at) FROM '$$PATH$$/3602.dat';

--
-- Data for Name: acc_usuario_grupos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.acc_usuario_grupos (id, usuario_id, grupo_id, enabled, created_at, updated_at) FROM stdin;
\.
COPY public.acc_usuario_grupos (id, usuario_id, grupo_id, enabled, created_at, updated_at) FROM '$$PATH$$/3588.dat';

--
-- Data for Name: clasificaciones; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.clasificaciones (id, nombre, created_at, updated_at, enabled) FROM stdin;
\.
COPY public.clasificaciones (id, nombre, created_at, updated_at, enabled) FROM '$$PATH$$/3590.dat';

--
-- Data for Name: departamentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.departamentos (id, nombre, created_at, updated_at, enabled) FROM stdin;
\.
COPY public.departamentos (id, nombre, created_at, updated_at, enabled) FROM '$$PATH$$/3592.dat';

--
-- Data for Name: especies; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.especies (id, nombre, created_at, updated_at, enabled, talla_min, talla_max, peso_min, peso_max, talla_menor_a, tipo1) FROM stdin;
\.
COPY public.especies (id, nombre, created_at, updated_at, enabled, talla_min, talla_max, peso_min, peso_max, talla_menor_a, tipo1) FROM '$$PATH$$/3596.dat';

--
-- Data for Name: failed_jobs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM stdin;
\.
COPY public.failed_jobs (id, uuid, connection, queue, payload, exception, failed_at) FROM '$$PATH$$/3598.dat';

--
-- Data for Name: flotas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.flotas (id, nombre, created_at, updated_at, enabled) FROM stdin;
\.
COPY public.flotas (id, nombre, created_at, updated_at, enabled) FROM '$$PATH$$/3600.dat';

--
-- Data for Name: formularios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.formularios (id, titulo, descripcion, created_at, updated_at, enabled) FROM stdin;
\.
COPY public.formularios (id, titulo, descripcion, created_at, updated_at, enabled) FROM '$$PATH$$/3594.dat';

--
-- Data for Name: grupos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.grupos (id, nombre, descripcion, enabled, created_at, updated_at) FROM stdin;
\.
COPY public.grupos (id, nombre, descripcion, enabled, created_at, updated_at) FROM '$$PATH$$/3604.dat';

--
-- Data for Name: lugar_m; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.lugar_m (id, nombre, created_at, updated_at, enabled) FROM stdin;
\.
COPY public.lugar_m (id, nombre, created_at, updated_at, enabled) FROM '$$PATH$$/3606.dat';

--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, migration, batch) FROM stdin;
\.
COPY public.migrations (id, migration, batch) FROM '$$PATH$$/3608.dat';

--
-- Data for Name: naves; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.naves (id, nombre, created_at, updated_at, enabled, flota_id) FROM stdin;
\.
COPY public.naves (id, nombre, created_at, updated_at, enabled, flota_id) FROM '$$PATH$$/3610.dat';

--
-- Data for Name: password_reset_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.password_reset_tokens (email, token, created_at) FROM stdin;
\.
COPY public.password_reset_tokens (email, token, created_at) FROM '$$PATH$$/3612.dat';

--
-- Data for Name: personal_access_tokens; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM stdin;
\.
COPY public.personal_access_tokens (id, tokenable_type, tokenable_id, name, token, abilities, last_used_at, expires_at, created_at, updated_at) FROM '$$PATH$$/3613.dat';

--
-- Data for Name: personas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.personas (id, nombre, created_at, updated_at, enabled, apellido, rut) FROM stdin;
\.
COPY public.personas (id, nombre, created_at, updated_at, enabled, apellido, rut) FROM '$$PATH$$/3615.dat';

--
-- Data for Name: plantas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.plantas (id, nombre, created_at, updated_at, enabled) FROM stdin;
\.
COPY public.plantas (id, nombre, created_at, updated_at, enabled) FROM '$$PATH$$/3617.dat';

--
-- Data for Name: privilegio_maestros; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.privilegio_maestros (id, nombre, descripcion, enabled, created_at, updated_at) FROM stdin;
\.
COPY public.privilegio_maestros (id, nombre, descripcion, enabled, created_at, updated_at) FROM '$$PATH$$/3619.dat';

--
-- Data for Name: puertos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.puertos (id, nombre, created_at, updated_at, enabled) FROM stdin;
\.
COPY public.puertos (id, nombre, created_at, updated_at, enabled) FROM '$$PATH$$/3621.dat';

--
-- Data for Name: resp_formularios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resp_formularios (id, formulario_id, json, created_at, updated_at, enabled, usuario_id) FROM stdin;
\.
COPY public.resp_formularios (id, formulario_id, json, created_at, updated_at, enabled, usuario_id) FROM '$$PATH$$/3623.dat';

--
-- Data for Name: resp_storage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.resp_storage (id, nombre, url, respuesta_id, created_at, updated_at) FROM stdin;
\.
COPY public.resp_storage (id, nombre, url, respuesta_id, created_at, updated_at) FROM '$$PATH$$/3624.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM stdin;
\.
COPY public.users (id, name, email, email_verified_at, password, remember_token, created_at, updated_at) FROM '$$PATH$$/3627.dat';

--
-- Data for Name: usuarios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuarios (id, username, password, google_id, email, enabled, created_at, updated_at, persona_id) FROM stdin;
\.
COPY public.usuarios (id, username, password, google_id, email, enabled, created_at, updated_at, persona_id) FROM '$$PATH$$/3629.dat';

--
-- Name: acc_formulario_grupo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acc_formulario_grupo_id_seq', 2, true);


--
-- Name: acc_usuario_grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.acc_usuario_grupos_id_seq', 3, true);


--
-- Name: clasificaciones_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.clasificaciones_id_seq', 84, true);


--
-- Name: departamentos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.departamentos_id_seq', 13, true);


--
-- Name: encuestas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.encuestas_id_seq', 2, true);


--
-- Name: especies_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.especies_id_seq', 22, true);


--
-- Name: failed_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.failed_jobs_id_seq', 1, false);


--
-- Name: flotas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.flotas_id_seq', 12, true);


--
-- Name: grupo_privilegio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grupo_privilegio_id_seq', 3, true);


--
-- Name: grupos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.grupos_id_seq', 2, true);


--
-- Name: lugar_m_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.lugar_m_id_seq', 4, true);


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 4, true);


--
-- Name: naves_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.naves_id_seq', 7, true);


--
-- Name: personal_access_tokens_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personal_access_tokens_id_seq', 136, true);


--
-- Name: personas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.personas_id_seq', 6, true);


--
-- Name: plantas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.plantas_id_seq', 12, true);


--
-- Name: privilegio_maestro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.privilegio_maestro_id_seq', 2, true);


--
-- Name: puertos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.puertos_id_seq', 35, true);


--
-- Name: resp_storage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.resp_storage_id_seq', 16, true);


--
-- Name: respuestas_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.respuestas_id_seq', 52, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: usuarios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuarios_id_seq', 9, true);


--
-- Name: acc_formulario_grupos acc_formulario_grupo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_formulario_grupos
    ADD CONSTRAINT acc_formulario_grupo_pk PRIMARY KEY (id);


--
-- Name: acc_usuario_grupos acc_usuario_grupos_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_usuario_grupos
    ADD CONSTRAINT acc_usuario_grupos_pk PRIMARY KEY (id);


--
-- Name: clasificaciones clasificaciones_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.clasificaciones
    ADD CONSTRAINT clasificaciones_pkey PRIMARY KEY (id);


--
-- Name: departamentos departamentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.departamentos
    ADD CONSTRAINT departamentos_pkey PRIMARY KEY (id);


--
-- Name: formularios encuestas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.formularios
    ADD CONSTRAINT encuestas_pkey PRIMARY KEY (id);


--
-- Name: especies especies_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.especies
    ADD CONSTRAINT especies_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_pkey PRIMARY KEY (id);


--
-- Name: failed_jobs failed_jobs_uuid_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.failed_jobs
    ADD CONSTRAINT failed_jobs_uuid_unique UNIQUE (uuid);


--
-- Name: flotas flotas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.flotas
    ADD CONSTRAINT flotas_pkey PRIMARY KEY (id);


--
-- Name: grupos grupo_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.grupos
    ADD CONSTRAINT grupo_pk PRIMARY KEY (id);


--
-- Name: acc_grupo_privilegios grupo_privilegio_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_grupo_privilegios
    ADD CONSTRAINT grupo_privilegio_pk PRIMARY KEY (id);


--
-- Name: lugar_m lugar_m_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.lugar_m
    ADD CONSTRAINT lugar_m_pkey PRIMARY KEY (id);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: naves naves_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.naves
    ADD CONSTRAINT naves_pkey PRIMARY KEY (id);


--
-- Name: password_reset_tokens password_reset_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.password_reset_tokens
    ADD CONSTRAINT password_reset_tokens_pkey PRIMARY KEY (email);


--
-- Name: personal_access_tokens personal_access_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_pkey PRIMARY KEY (id);


--
-- Name: personal_access_tokens personal_access_tokens_token_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personal_access_tokens
    ADD CONSTRAINT personal_access_tokens_token_unique UNIQUE (token);


--
-- Name: personas personas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.personas
    ADD CONSTRAINT personas_pkey PRIMARY KEY (id);


--
-- Name: plantas plantas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.plantas
    ADD CONSTRAINT plantas_pkey PRIMARY KEY (id);


--
-- Name: privilegio_maestros privilegio_maestro_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.privilegio_maestros
    ADD CONSTRAINT privilegio_maestro_pk PRIMARY KEY (id);


--
-- Name: puertos puertos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.puertos
    ADD CONSTRAINT puertos_pkey PRIMARY KEY (id);


--
-- Name: resp_storage resp_storage_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resp_storage
    ADD CONSTRAINT resp_storage_pk PRIMARY KEY (id);


--
-- Name: resp_formularios respuestas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resp_formularios
    ADD CONSTRAINT respuestas_pkey PRIMARY KEY (id);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: usuarios usuarios_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_pk PRIMARY KEY (id);


--
-- Name: usuarios usuarios_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_unique UNIQUE (username);


--
-- Name: clasificaciones_nombre_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX clasificaciones_nombre_idx ON public.clasificaciones USING btree (nombre);


--
-- Name: departamentos_nombre_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX departamentos_nombre_idx ON public.departamentos USING btree (nombre);


--
-- Name: especies_nombre_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX especies_nombre_idx ON public.especies USING btree (nombre);


--
-- Name: flotas_nombre_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX flotas_nombre_idx ON public.flotas USING btree (nombre);


--
-- Name: formularios_titulo_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX formularios_titulo_idx ON public.formularios USING btree (titulo);


--
-- Name: lugar_m_nombre_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX lugar_m_nombre_idx ON public.lugar_m USING btree (nombre);


--
-- Name: personal_access_tokens_tokenable_type_tokenable_id_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX personal_access_tokens_tokenable_type_tokenable_id_index ON public.personal_access_tokens USING btree (tokenable_type, tokenable_id);


--
-- Name: plantas_nombre_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX plantas_nombre_idx ON public.plantas USING btree (nombre);


--
-- Name: puertos_nombre_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX puertos_nombre_idx ON public.puertos USING btree (nombre);


--
-- Name: acc_formulario_grupos acc_formulario_grupo_formularios_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_formulario_grupos
    ADD CONSTRAINT acc_formulario_grupo_formularios_fk FOREIGN KEY (formulario_id) REFERENCES public.formularios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: acc_formulario_grupos acc_formulario_grupo_grupos_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_formulario_grupos
    ADD CONSTRAINT acc_formulario_grupo_grupos_fk FOREIGN KEY (grupo_id) REFERENCES public.grupos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: acc_usuario_grupos acc_usuario_grupos_grupos_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_usuario_grupos
    ADD CONSTRAINT acc_usuario_grupos_grupos_fk FOREIGN KEY (grupo_id) REFERENCES public.grupos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: acc_usuario_grupos acc_usuario_grupos_usuarios_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_usuario_grupos
    ADD CONSTRAINT acc_usuario_grupos_usuarios_fk FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: acc_grupo_privilegios grupo_privilegio_grupos_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_grupo_privilegios
    ADD CONSTRAINT grupo_privilegio_grupos_fk FOREIGN KEY (grupo_id) REFERENCES public.grupos(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: acc_grupo_privilegios grupo_privilegio_privilegio_maestro_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.acc_grupo_privilegios
    ADD CONSTRAINT grupo_privilegio_privilegio_maestro_fk FOREIGN KEY (privilegio_id) REFERENCES public.privilegio_maestros(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: naves naves_flotas_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.naves
    ADD CONSTRAINT naves_flotas_fk FOREIGN KEY (flota_id) REFERENCES public.flotas(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: resp_formularios resp_formularios_formularios_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resp_formularios
    ADD CONSTRAINT resp_formularios_formularios_fk FOREIGN KEY (formulario_id) REFERENCES public.formularios(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: resp_formularios resp_formularios_usuarios_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resp_formularios
    ADD CONSTRAINT resp_formularios_usuarios_fk FOREIGN KEY (usuario_id) REFERENCES public.usuarios(id);


--
-- Name: resp_storage resp_storage_resp_formularios_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.resp_storage
    ADD CONSTRAINT resp_storage_resp_formularios_fk FOREIGN KEY (respuesta_id) REFERENCES public.resp_formularios(id) ON UPDATE RESTRICT ON DELETE RESTRICT;


--
-- Name: usuarios usuarios_personas_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuarios
    ADD CONSTRAINT usuarios_personas_fk FOREIGN KEY (persona_id) REFERENCES public.personas(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

